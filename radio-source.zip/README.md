# Radio (Terrainfinity)

TanStack Start + Vite app for radio.terrainfinity.ca / radio.cyber-athens.ca.

## Run

```bash
npm install
cp .env.example .env
npm run dev
```

Dev server: `http://localhost:8080`

```bash
npm run build
npm run preview
```

## Env

Google login lives on the hub only (`https://www.terrainfinity.ca`). Do not set `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET`, or `AUTH_URL=https://www.terrainfinity.ca` on Radio.

| Name | Notes |
|---|---|
| `SSO_HUB` | `https://www.terrainfinity.ca` |
| `AUTH_SECRET` | Same as the hub if sharing the `*.terrainfinity.ca` cookie |
| `AUTH_COOKIE_DOMAIN` | `.terrainfinity.ca` in prod only — never on localhost |
| `SSO_ALLOWED_ORIGINS` | Radio hosts allowed to start/redeem SSO |
| `DATABASE_URL` | Postgres / Neon. Omit locally to use in-memory PGLite |
| `R2_*` | Optional Cloudflare R2 for uploads |

Sign-in from Radio goes to `{SSO_HUB}/api/sso/start` and returns to this origin’s `/api/sso/consume`.

## Desk

`/desk` — C-only station builder (featured rail, playlists, copy/move cuts, R2).
